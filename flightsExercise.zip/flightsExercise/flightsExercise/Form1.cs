﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Reflection;

namespace flightsExercise
{
    public partial class Form1 : Form
    {
        static string requestType = "";
        static List<FlightsValues> values;
        FlightsValues f = new FlightsValues();

        public Form1()
        {
            InitializeComponent();

            string path = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), @"..\..\flights.csv");
            values = File.ReadAllLines(path)
                                               .Skip(1)
                                               .Select(v => FlightsValues.FromCsv(v))
                                               .ToList();


            cmbCityA.DataSource = f.CityNameList(values, "OriginCityName").ToList();
            cmbCityA.DisplayMember = "OriginCityName";

            cmbCityB.DataSource = f.CityNameList(values, "DestCityName").ToList();
            cmbCityB.DisplayMember = "DestCityName";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            cmbCityA.Visible = true;
            cmbCityB.Visible = true;
            requestType = "A";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            cmbCityA.Visible = true;
            cmbCityB.Visible = false;
            requestType = "B";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            cmbCityA.Visible = true;
            cmbCityB.Visible = false;
            requestType = "C";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            switch (requestType)
            {
                case "A":
                    List<decimal> d = f.GetAvgDelays(values, cmbCityA.SelectedItem.ToString(), cmbCityB.SelectedItem.ToString());
                    TxtResult.Text = cmbCityA.SelectedItem.ToString() + ", " + cmbCityB.SelectedItem.ToString() + " Based on " + d[2] + "flishts" +
                        " The Avg DepDelay is:" + Decimal.Round(d[0], 2) + " The avg ArrDelay is:" + Decimal.Round(d[1], 2);
                    break;
                case "B":
                    decimal maxfli = f.GetMaxFlights(values, cmbCityA.SelectedItem.ToString());
                    TxtResult.Text = " Most flights from " + cmbCityA.SelectedItem.ToString() +
                        " is in airline: " + maxfli;
                    break;
                case "C":
                    IEnumerable<string> maxDistance = f.GetMaxDistFlights(values, cmbCityA.SelectedItem.ToString());
                    TxtResult.Text = " The 5 farthest destination from " + cmbCityA.SelectedItem.ToString() +
                        " are: ";
                    foreach (var objUnknown in maxDistance)
                    {
                        TxtResult.Text += objUnknown.ToString();
                    }

                    break;
            }
        }

        private void TxtResult_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
