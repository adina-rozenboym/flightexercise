﻿using Microsoft.VisualBasic.FileIO;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace flightsExercise
{
    class FlightsValues
    {
        string OriginCityName;
        string DestCityName;
        decimal DepDelayMinutes;
        decimal ArrDelayMinutes;
        decimal AirlineID;
        decimal Distance;
       
        public static FlightsValues FromCsv(string csvLine)
        {
            decimal number;

            TextFieldParser parser = new TextFieldParser(new StringReader(csvLine));

            parser.HasFieldsEnclosedInQuotes = true;
            parser.SetDelimiters(",");

            string[] values = parser.ReadFields();// csvLine.Split(',');
            FlightsValues flightsValues = new FlightsValues();
            flightsValues.OriginCityName = values[16];
            flightsValues.DestCityName = values[25];
            flightsValues.DepDelayMinutes = Decimal.TryParse(values[33], out number) ? number : 0;
            flightsValues.ArrDelayMinutes = Decimal.TryParse(values[44], out number) ? number : 0; ;
            flightsValues.AirlineID = Decimal.TryParse(values[8], out number) ? number : 0; ;
            flightsValues.Distance = Decimal.TryParse(values[55], out number) ? number : 0; ;

            parser.Close();

            return flightsValues;
        }

        public IEnumerable<string> CityNameList(List<FlightsValues> values, string columnName)
        {
            if (columnName == "OriginCityName")
                return values.Select(o => o.OriginCityName).Distinct();
            else
                return values.Select(o => o.DestCityName).Distinct();
        }

        public List<decimal> GetAvgDelays(List<FlightsValues> values, string cityA, string cityB)
        {
            IEnumerable<FlightsValues> listfli = values.Where(o => o.OriginCityName == cityA)
                         .Where(o => o.DestCityName == cityB)
                         .Select(o => new FlightsValues { DepDelayMinutes = o.DepDelayMinutes, ArrDelayMinutes = o.ArrDelayMinutes })
                         .ToList();
            List<decimal> d = new List<decimal>();
            d.Add(listfli.Average(o => o.DepDelayMinutes));
            d.Add(listfli.Average(o => o.ArrDelayMinutes));
            d.Add(listfli.Count());

            return d;
           
        }

        public decimal GetMaxFlights(List<FlightsValues> values, string cityA)
        {
            decimal maxfli = values.Where(o => o.OriginCityName == cityA)
                         .GroupBy(o => o.AirlineID)
                         .Select(group => new
                         {
                             AirlineID = group.Key,
                             Count = group.Count()
                         }).OrderByDescending(group => group.Count)
                         .First().AirlineID;

            return maxfli;
        }

        public IEnumerable<string> GetMaxDistFlights(List<FlightsValues> values, string cityA)
        {
            IEnumerable<string> maxDistance = values.Where(o => o.OriginCityName == cityA)
                .OrderByDescending(o => o.Distance)
                .Select(o => o.DestCityName)
                .Distinct()
                .Take(5);
            return maxDistance;
        }
    }
}
